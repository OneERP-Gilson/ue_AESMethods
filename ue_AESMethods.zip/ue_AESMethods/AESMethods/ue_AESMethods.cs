﻿using Mongoose.IDO;
using Mongoose.IDO.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ue_AESMethods
{
    [IDOExtensionClass("AESMethods")]
    public partial class AESMethods : IDOExtensionClass
    {
        [IDOMethod(MethodFlags.None, "Infobar")]
        public short GetUseProfile(string TaskNumber, ref string UseProfile)
        {
            UseProfile = GetUseProfileProcess(TaskNumber, this.Context.Commands);
            return 0;
        }

        [IDOMethod(MethodFlags.None, "Infobar")]
        public short SendToLocalTaskPrinter(string TaskNumber, string CustEmail)
        {
            if (!string.IsNullOrEmpty(CustEmail)) return 0;
            return SendToLocalTaskPrinterProcess(this.Context.Commands, TaskNumber);
        }

        [IDOMethod(MethodFlags.None, "Infobar")]
        public short GetInvNumber(string TaskParms, ref string InvNum)
        {
            InvNum = GetInvNumProcess(TaskParms);

            return 0;
        }

        public string GetInvNumProcess(string TaskParms)
        {
            var splitParms = TaskParms.Split(',');
            string InvNum = "";

            foreach (string parm in splitParms)
            {
                if (parm.Contains("SubStartInvNum"))
                {
                    char[] charArray = parm.ToCharArray();

                    for (int i = 0; i < charArray.Length; i++)
                    {
                        if (char.IsDigit(charArray[i]))
                        {
                            InvNum += charArray[i];
                        }
                    }

                    return InvNum.PadLeft(10);
                }
            }

            return InvNum.PadLeft(10);
        }

        public short SendToLocalTaskPrinterProcess(IIDOCommands commands, string TaskNumber)
        {
            LoadCollectionResponseData response = new LoadCollectionResponseData();
            string filter = $"TaskNumber = {TaskNumber}";
            response = commands.LoadCollection("BGTaskHistories", "RequestingUser,Initiator,TaskName,TaskParm,RowPointer", filter, "", 0);

            if (response.Items.Count > 0)
            {
                string taskParms = response[0, "TaskParm"].Value;
                string[] splitParms = taskParms.Split(',');
                string reprintString = "";
                string localPrint = "";

                if (splitParms[0].Contains("ProcessReprint"))
                {
                    reprintString = splitParms[0].Replace("ProcessReprint", "");
                }
                else
                {
                    reprintString = splitParms[1].Replace("ProcessReprint=", "");
                    
                }

                foreach (var parm in splitParms)
                {
                    if (parm.Contains("LocalPrint"))
                    {
                        localPrint = parm.FirstOrDefault(c => char.IsDigit(c)).ToString();
                        break;
                    }
                }

                if (localPrint != "1" && reprintString.ToLower().Contains("reprint"))
                {
                    return 0;
                }

                LoadCollectionResponseData localReportOptions = new LoadCollectionResponseData();
                string requestingUser = response[0, "RequestingUser"].Value;
                string taskName = response[0, "TaskName"].Value;
                filter = $"Username = '{requestingUser}' AND TaskName = '{taskName}'";
                localReportOptions = commands.LoadCollection("ue_SXLocalReportOptionsEmail", "Username,TaskName,PrinterName,NumCopies", filter, "", 0);

                if (localReportOptions.Items.Count > 0)
                {
                    string printerName = localReportOptions[0, "PrinterName"].Value;
                    string numCopies = localReportOptions[0, "NumCopies"].Value;
                    string rowPointer = response[0, "RowPointer"].Value;

                    string printString = $"PrinterName={printerName},TaskHistoryRowPointer={rowPointer},NumCopies={numCopies}";

                    UpdateCollectionRequestData updateRequest = new UpdateCollectionRequestData();
                    IDOUpdateItem updateItem = new IDOUpdateItem();

                    updateItem.Action = UpdateAction.Insert;
                    updateItem.Properties.Add("TaskTypeCode", "LP", true);
                    updateItem.Properties.Add("TaskParms", printString, true);
                    //updateItem.Properties.Add("CompletionStatus", "1", true);

                    updateRequest.IDOName = "ue_SXLocalBGTasks";
                    updateRequest.Items.Add(updateItem);

                    commands.UpdateCollection(updateRequest);
                }
            }

            return 0;
        }

        public string GetUseProfileProcess(string TaskNumber, IIDOCommands commands)
        {
            LoadCollectionResponseData response = new LoadCollectionResponseData();
            string filter = $"TaskNumber = {TaskNumber}";
            string UseProfile = "0";
            double numericUseProfile = 0;
            response = commands.LoadCollection("BGTaskHistories", "RequestingUser,Initiator,TaskName,TaskParm", filter, "", 0);

            if (response.Items.Count > 0)
            {
                string TaskParm = response[0, "TaskParm"].Value.ToLower();
                string[] parms = TaskParm.Split(',');

                foreach (string parm in parms)
                {
                    if (parm.Contains("useprofile"))
                    {
                        UseProfile = parm.FirstOrDefault(c => char.IsDigit(c)).ToString();
                        return UseProfile;
                    }
                }

                string requestingUser = response[0, "RequestingUser"].Value;
                string taskName = response[0, "TaskName"].Value;

                if (taskName == "OrderInvoicingCreditMemoReportLaser")
                {
                    UseProfile = GetUseProfileInvoicingBGSp(requestingUser, commands);
                }

            }

            if (double.TryParse(UseProfile, out numericUseProfile))
            {
                return UseProfile;
            }
            else
            {
                UseProfile = UseProfile.FirstOrDefault(c => char.IsDigit(c)).ToString();
            }

            return UseProfile;
        }

        private string GetUseProfileInvoicingBGSp(string requestingUser, IIDOCommands commands)
        {
            string filter = $"TaskName = 'InvoicingBGSp' AND RequestingUser = '{requestingUser}'";
            LoadCollectionResponseData response = commands.LoadCollection("BGTaskHistories", "RequestingUser,Initiator,TaskName,TaskParm", filter, "CreateDate DESC", 1);

            if (response.Items.Count > 0)
            {
                string taskParms = response[0, "TaskParm"].Value;
                string[] splitParms = taskParms.Split(',');

                return splitParms[66];
            }

            return "0";
        }
    }

}
