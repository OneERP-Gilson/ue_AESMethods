﻿using Mongoose.IDO;
using Mongoose.IDO.Protocol;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ue_AESMethods;

namespace ue_AESMethods
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Client = new Client("https://csi10a.erpsl.inforcloudsuite.com/IDORequestService/RequestService.aspx?ConfigGroup=GILSON", IDOProtocol.Http);

            Client.OpenSession("", "", "GILSON_TRN_GLUS");
            var aesMethods = new AESMethods();
            string Infobar = "";
            //string test = aesMethods.GetUseProfileProcess("373070", Client);
            //aesMethods.SendToLocalTaskPrinterProcess(Client, "373070");
            Infobar = aesMethods.GetInvNumProcess("SETVARVALUES(ProcessReprint = PROCESS,StartSRONum = ,EndSRONum = ,StartSROLine = ,EndSROLine = ,StartSROOper = ,EndSROOper = ,StartBillMgr = ,EndBillMgr = ,StartCustNum =   24645,EndCustNum =   24645,StartRegion = ,EndRegion = ,StartTransDate = ,EndTransDate = ,StartCloseDate = ,EndCloseDate = ,InclCalculated = 1,InclProject = 1,InvCred = I,InvDate = 20210526,TransToDomCurr = 0,SortBy = S,SubStartInvNum = 500148,SubEndInvNum = 500148,StartReprintInvDate = 20210526,EndReprintInvDate = 20210526,PrintCustomerNotes = 1,PrintSRONotes = 0,PrintSROLineNotes = 0,PrintSROOperNotes = 0,PrintTransNotes = 0,PrintInternalNotes = 0,PrintExternalNotes = 1,PrintSerials = 0,PrintMatl = 1,PrintLabor = 1,PrintMisc = 1,SummarizeTrans = 0,ShipToAddress = U,PrintEuroTotal = 0,OrderBy = N,UseProfile = 1)");
            //var response = Client.LoadCollection("FSSROInvHdrs", "InvNum", "InvNum = '500148'", "", 0);
            Client.CloseSession();
        }
    }

}
